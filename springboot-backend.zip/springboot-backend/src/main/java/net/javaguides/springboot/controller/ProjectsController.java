package net.javaguides.springboot.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.EmployeeRegistration;
//import net.javaguides.springboot.model.Employee;
import net.javaguides.springboot.model.Projects;
import net.javaguides.springboot.repository.EmployeeRegistrationRepository;
//import net.javaguides.springboot.repository.EmployeeRepository;
import net.javaguides.springboot.repository.ProjectsRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/projects")

public class ProjectsController {


    @Autowired
    private ProjectsRepository projectRepository;

    @Autowired
    private EmployeeRegistrationRepository employeeRegistrationRepository;

    @GetMapping
    public List<Projects> getProjects() {
        return projectRepository.findAll();
    }

    @PostMapping
    public Projects createProject(@RequestBody Projects project) {
        return projectRepository.save(project);
    }

    @GetMapping("/{id}")
    public Projects getProjectById(@PathVariable Long id) {
        return projectRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Project not found"));
    }

    @PutMapping("/{id}")
    public Projects updateProject(@PathVariable Long id, @RequestBody Projects projectDetails) {
        Projects project = projectRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Project not found"));
        project.setProjectName(projectDetails.getProjectName());
        project.setDescription(projectDetails.getDescription());
        project.setStartDate(projectDetails.getStartDate());
        project.setEndDate(projectDetails.getEndDate());
        return projectRepository.save(project);
    }

    @DeleteMapping("/{id}")
    public void deleteProject(@PathVariable Long id) {
        Projects project = projectRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Project not found"));
        projectRepository.delete(project);
    }

    @PostMapping("/allocate")
    public void allocateProject(@RequestBody Map<String, Long> allocation) {
        Long employeeId = allocation.get("employeeId");
        Long projectId = allocation.get("projectId");
        EmployeeRegistration employeeRegistration = employeeRegistrationRepository.findById(employeeId).orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        Projects project = projectRepository.findById(projectId).orElseThrow(() -> new ResourceNotFoundException("Project not found"));
        employeeRegistration.setStatus("allocated");
        employeeRegistrationRepository.save(employeeRegistration);
    }
}
