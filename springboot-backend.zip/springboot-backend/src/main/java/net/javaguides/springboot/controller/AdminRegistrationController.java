//package net.javaguides.springboot.controller;
//
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import net.javaguides.springboot.exception.ResourceNotFoundException;
//import net.javaguides.springboot.model.AdminRegistration;
//import net.javaguides.springboot.repository.AdminRegistrationRepository;
//
//
//@CrossOrigin(origins = "http://localhost:4200")
//@RestController
//@RequestMapping("/api/v1/")
//public class AdminRegistrationController {
//
//	@Autowired
//	private AdminRegistrationRepository adminRegistrationRepository;
//	
//	// get all employees
//	@GetMapping("/admin_registrations")
//	public List<AdminRegistration> getAllAdminRegistration(){
//		return adminRegistrationRepository.findAll();
//	}		
//	
//	// create employee rest api
//	@PostMapping("/admin_registrations")
//	public AdminRegistration createAdminRegistration(@RequestBody AdminRegistration adminRegistration) {
//		return adminRegistrationRepository.save(adminRegistration);
//	}
//	
//	
//	// get employee by id rest api
//	@GetMapping("/admin_registrations/{id}")
//	public ResponseEntity<AdminRegistration> getAdminRegistrationById(@PathVariable Long id) {
//		AdminRegistration adminRegistration = adminRegistrationRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Admin not exist with id :" + id));
//		return ResponseEntity.ok(adminRegistration);
//	}
//	// update employee rest api
//	
//	@PutMapping("/admin_registrations/{id}")
//	public ResponseEntity<AdminRegistration> updateAdminRegistration(@PathVariable Long id, @RequestBody AdminRegistration adminRegistrationDetails){
//		AdminRegistration adminRegistration = adminRegistrationRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Admin not exist with id :" + id));
//		
//		adminRegistration.setId(adminRegistrationDetails.getId());
//		adminRegistration.setFirstName(adminRegistrationDetails.getFirstName());
//		adminRegistration.setLastName(adminRegistrationDetails.getLastName());
//		adminRegistration.setEmailId(adminRegistrationDetails.getEmailId());
//		adminRegistration.setDesignation(adminRegistrationDetails.getDesignation());
//		adminRegistration.setUserName(adminRegistrationDetails.getUserName());
//		adminRegistration.setPassword(adminRegistrationDetails.getPassword());
//		
//		AdminRegistration updatedAdminRegistration = adminRegistrationRepository.save(adminRegistration);
//		return ResponseEntity.ok(updatedAdminRegistration);
//	}
//	
//	// delete employee rest api
//	@DeleteMapping("/admin_registrations/{id}")
//	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
//		AdminRegistration adminRegistration = adminRegistrationRepository.findById(id)
//				.orElseThrow(() -> new ResourceNotFoundException("Admin not exist with id :" + id));
//		
//		adminRegistrationRepository.delete(adminRegistration);
//		Map<String, Boolean> response = new HashMap<>();
//		response.put("deleted", Boolean.TRUE);
//		return ResponseEntity.ok(response);
//	}
//	
//	
//}
