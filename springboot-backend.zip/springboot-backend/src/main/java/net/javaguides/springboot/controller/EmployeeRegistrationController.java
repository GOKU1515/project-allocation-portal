package net.javaguides.springboot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.exception.ResourceNotFoundException;
//import net.javaguides.springboot.model.AdminRegistration;
import net.javaguides.springboot.model.EmployeeRegistration;
import net.javaguides.springboot.repository.EmployeeRegistrationRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")


public class EmployeeRegistrationController {

	@Autowired
	private EmployeeRegistrationRepository employeeRegistrationRepository;
	
	@GetMapping("/employee_registrations")
	public List<EmployeeRegistration> getAllEmployeeRegistration(){
		return employeeRegistrationRepository.findAll();
		
	}
	
	@PostMapping("/employee_registrations")
	public EmployeeRegistration createEmployeeRegistration(@RequestBody EmployeeRegistration employeeRegistration) {
		return employeeRegistrationRepository.save(employeeRegistration);
	}
	
//	@GetMapping("/on-bench")
//    public List<EmployeeRegistration> getEmployeesOnBench() {
//        return employeeRegistrationRepository.findByStatus("on-bench");
//    }
	
	
	 @GetMapping("/employee_registrations/status")
	    public List<EmployeeRegistration> getEmployeesOnBench(@RequestParam String status) {
	        return employeeRegistrationRepository.findByStatus(status);
	    }
	 
//	 @GetMapping("/status")
//	    public ResponseEntity<List<EmployeeRegistration>> getEmployeesByStatus(@RequestParam String status) {
//	        List<EmployeeRegistration> employees = employeeRegistrationService.getEmployeesByStatus(status);
//	        return ResponseEntity.ok(employees);
//	    }
	
	@GetMapping("/employee_registrations/{id}")
	public ResponseEntity<EmployeeRegistration> getEmployeeRegistrationById(@PathVariable Long id) {
		EmployeeRegistration employeeRegistration = employeeRegistrationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		return ResponseEntity.ok(employeeRegistration);
	}
	
	@PutMapping("/employee_registrations/{id}")
	public ResponseEntity<EmployeeRegistration> updateEmployeeRegistration(@PathVariable Long id, @RequestBody EmployeeRegistration employeeRegistrationDetails){
		EmployeeRegistration employeeRegistration = employeeRegistrationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		
		employeeRegistration.setId(employeeRegistrationDetails.getId());
		employeeRegistration.setFirstName(employeeRegistrationDetails.getFirstName());
		employeeRegistration.setLastName(employeeRegistrationDetails.getLastName());
		employeeRegistration.setEmailId(employeeRegistrationDetails.getEmailId());
		employeeRegistration.setStatus(employeeRegistrationDetails.getStatus());
		employeeRegistration.setDesignation(employeeRegistrationDetails.getDesignation());
		employeeRegistration.setUserName(employeeRegistrationDetails.getUserName());
		employeeRegistration.setPassword(employeeRegistrationDetails.getPassword());
		
		EmployeeRegistration updatedEmployeeRegistration = employeeRegistrationRepository.save(employeeRegistration);
		return ResponseEntity.ok(updatedEmployeeRegistration);
	}
	
	@DeleteMapping("/employee_registrations/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id){
		EmployeeRegistration employeeRegistration = employeeRegistrationRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		
		employeeRegistrationRepository.delete(employeeRegistration);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
}

