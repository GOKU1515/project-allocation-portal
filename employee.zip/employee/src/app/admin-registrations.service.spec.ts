// import { TestBed } from '@angular/core/testing';

// import { AdminRegistrationsService } from './admin-registrations.service';

// describe('AdminRegistrationsService', () => {
//   let service: AdminRegistrationsService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(AdminRegistrationsService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });
