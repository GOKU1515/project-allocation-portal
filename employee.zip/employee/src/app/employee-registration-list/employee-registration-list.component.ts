import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-registration-list',
  templateUrl: './employee-registration-list.component.html',
  styleUrl: './employee-registration-list.component.css'
})
export class EmployeeRegistrationListComponent {

}
