import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeRegistrationListComponent } from './employee-registration-list.component';

describe('EmployeeRegistrationListComponent', () => {
  let component: EmployeeRegistrationListComponent;
  let fixture: ComponentFixture<EmployeeRegistrationListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeRegistrationListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmployeeRegistrationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
