// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { Project } from '../project';

// @Injectable({
//   providedIn: 'root'
// })
// export class ProjectService {

//   private baseURL = "http://localhost:8080/api/v1/projects";

//   constructor(private httpClient: HttpClient) { }

//   getProjects(): Observable<Project[]> {
//     return this.httpClient.get<Project[]>(`${this.baseURL}`);
//   }
  

//   allocateProject(employeeId: number, projectId: number): Observable<Object> {
//     return this.httpClient.post(`${this.baseURL}/allocate`, { employeeId, projectId });
//   }

//   // Other methods for creating, updating, deleting projects
// }


import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Project } from '../project';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  private baseURL = "http://localhost:8080/api/v1/projects";
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) { }

  getProjects(): Observable<Project[]> {
    return this.httpClient.get<Project[]>(`${this.baseURL}`);
  }

  allocateProject(employeeId: number, projectId: number): Observable<Object> {
         return this.httpClient.post(`${this.baseURL}/allocate`, { employeeId, projectId });
       }

  createProject(project: Project): Observable<Object> {
    return this.httpClient.post(`${this.baseURL}`, project, this.httpOptions);
  }

  getProjectById(id: number): Observable<Project> {
    return this.httpClient.get<Project>(`${this.baseURL}/${id}`);
  }

  updateProject(id: number, project: Project): Observable<Object> {
    return this.httpClient.put(`${this.baseURL}/${id}`, project, this.httpOptions);
  }

  deleteProject(id: number): Observable<Object> {
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }
}
