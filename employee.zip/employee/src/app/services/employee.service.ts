// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Observable, catchError, of, retry, throwError } from 'rxjs';
// import { Employee } from '../employee';

// @Injectable({
//   providedIn: 'root'
// })
// export class EmployeeService {

//   private baseURL = "http://localhost:8080/api/v1/employee_registrations";
//   private httpOptions = {
//     headers: new HttpHeaders({
//       'Content-Type': 'application/json'
//     })
//   };

//   constructor(private httpClient: HttpClient) { }

//   getEmployeesOnBench(): Observable<Employee[]> {
//     return this.httpClient.get<Employee[]>(`${this.baseURL}/on-bench`);
//   }

  

//   getEmployeesList(): Observable<Employee[]>{
//     return this.httpClient.get<Employee[]>(`${this.baseURL}`);
//   }

//   createEmployee(employee: Employee): Observable<Object>{
//     return this.httpClient.post(`${this.baseURL}`, employee);
//   }

//   getEmployeeById(id: number): Observable<Employee>{
//     return this.httpClient.get<Employee>(`${this.baseURL}/${id}`);
//   }

//   updateEmployee(id: number, employee: Employee): Observable<Object>{
//     return this.httpClient.put(`${this.baseURL}/${id}`, employee);
//   }

//   deleteEmployee(id: number): Observable<Object>{
//     return this.httpClient.delete(`${this.baseURL}/${id}`);
//   }

//   // Other methods for updating, deleting, etc.
// }



import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, catchError, of, retry, throwError } from 'rxjs';
import { Employee } from '../employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseURL = "http://localhost:8080/api/v1/employee_registrations";
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) { }

  // getEmployeesOnBench(): Observable<Employee[]> {
  //   return this.httpClient.get<Employee[]>(`${this.baseURL}/on-bench`);
  // }


  // getEmployeesOnBench(): Observable<Employee[]> {
  //   return this.httpClient.get<Employee[]>(`${this.baseURL}/on-bench`);
  // }


  // Fetch employees with status "on-bench"
  getEmployeesOnBench(): Observable<Employee[]> {
    return this.httpClient.get<Employee[]>(`${this.baseURL}/status`, { params: { status: 'on-bench' } });
  }

  
  // createEmployee(employee: Employee): Observable<Object> {
  //   return this.httpClient.post(`${this.baseURL}`, JSON.stringify(employee), this.httpOptions).pipe(
  //     retry(3),
  //     catchError((error) => {
  //       console.error(error);
  //       return throwError(error); // explicitly returning an observable
  //     })
  //   );
  // }

  getEmployeesList(): Observable<Employee[]>{
    return this.httpClient.get<Employee[]>(`${this.baseURL}`);
  }

  createEmployee(employee: Employee): Observable<Object>{
    return this.httpClient.post(`${this.baseURL}`, employee);
  }

  getEmployeeById(id: number): Observable<Employee>{
    return this.httpClient.get<Employee>(`${this.baseURL}/${id}`);
  }

  updateEmployee(id: number, employee: Employee): Observable<Object>{
    return this.httpClient.put(`${this.baseURL}/${id}`, employee);
  }

  deleteEmployee(id: number): Observable<Object>{
    return this.httpClient.delete(`${this.baseURL}/${id}`);
  }

  // Other methods for updating, deleting, etc.
}