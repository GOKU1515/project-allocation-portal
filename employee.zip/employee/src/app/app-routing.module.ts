import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { EmployeeRegistrationListComponent } from './employee-registration-list/employee-registration-list.component';
//import { EmployeeRegistrationsComponent } from './employee-registrations/employee-registrations.component';
import { UpdateEmployeeRegistrationComponent } from './update-employee-registration/update-employee-registration.component';
import { EmployeeRegistrationDetailsComponent } from './employee-registration-details/employee-registration-details.component';

import { EmployeesComponent } from './employees/employees.component';
import { ProjectsComponent } from './projects/projects.component';
import { AllocationsComponent } from './allocations/allocations.component';
import { CreateProjectsComponent } from './create-projects/create-projects.component';



const routes: Routes = [
  {path: 'employees-registration-list', component: EmployeeRegistrationListComponent},
 // {path: 'employee-registrations', component: EmployeeRegistrationsComponent},
 // {path: '', redirectTo: 'employees', pathMatch: 'full'},
  {path: 'update-employee-registration/:id', component: UpdateEmployeeRegistrationComponent},
  {path: 'employee-registration-details/:id', component: EmployeeRegistrationDetailsComponent},

  {path: 'employees', component: EmployeeListComponent},
  {path: 'create-employee', component: CreateEmployeeComponent},
  {path: '', redirectTo: 'employees', pathMatch: 'full'},
  {path: 'update-employee/:id', component: UpdateEmployeeComponent},
  {path: 'employee-details/:id', component: EmployeeDetailsComponent},

   { path: 'employees1', component: EmployeesComponent },
  { path: 'projects', component: ProjectsComponent },
  { path: 'allocations', component: AllocationsComponent },

  { path: 'create-projects', component: CreateProjectsComponent },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],                                                                                                                                                                                                                                                                                                          
  exports: [RouterModule]
})
export class AppRoutingModule { }
