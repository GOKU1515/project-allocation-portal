import { Component } from '@angular/core';

@Component({
  selector: 'app-update-employee-registration',
  templateUrl: './update-employee-registration.component.html',
  styleUrl: './update-employee-registration.component.css'
})
export class UpdateEmployeeRegistrationComponent {

}
