import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateEmployeeRegistrationComponent } from './update-employee-registration.component';

describe('UpdateEmployeeRegistrationComponent', () => {
  let component: UpdateEmployeeRegistrationComponent;
  let fixture: ComponentFixture<UpdateEmployeeRegistrationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UpdateEmployeeRegistrationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UpdateEmployeeRegistrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
