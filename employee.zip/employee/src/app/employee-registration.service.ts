// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http'
// import { Observable } from 'rxjs';
// import { EmployeeRegistration } from './employee-registration';

// @Injectable({
//   providedIn: 'root'
// })
// export class EmployeeRegistrationService {

//   private baseURL = "http://localhost:8080/api/v1/employees";

//   constructor(private httpClient: HttpClient) { }
  
//   getEmployeesList(): Observable<EmployeeRegistration[]>{
//     return this.httpClient.get<EmployeeRegistration[]>(`${this.baseURL}`);
//   }

//   createEmployee(employee: EmployeeRegistration): Observable<Object>{
//     return this.httpClient.post(`${this.baseURL}`, employee);
//   }

//   getEmployeeById(id: number): Observable<EmployeeRegistration>{
//     return this.httpClient.get<EmployeeRegistration>(`${this.baseURL}/${id}`);
//   }

//   updateEmployee(id: number, employee: EmployeeRegistration): Observable<Object>{
//     return this.httpClient.put(`${this.baseURL}/${id}`, employee);
//   }

//   deleteEmployee(id: number): Observable<Object>{
//     return this.httpClient.delete(`${this.baseURL}/${id}`);
//   }
// }
