import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { FormsModule} from '@angular/forms';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { AllocationsComponent } from './allocations/allocations.component';
import { EmployeesComponent } from './employees/employees.component';
import { ProjectsComponent } from './projects/projects.component';
import { CreateProjectsComponent } from './create-projects/create-projects.component';
// import { AdminRegistrationsComponent } from './admin-registrations/admin-registrations.component';
// import { EmployeeRegistrationsComponent } from './employee-registrations/employee-registrations.component';
// import { EmployeeRegistrationDetailsComponent } from './employee-registration-details/employee-registration-details.component';
// import { EmployeeRegistrationListComponent } from './employee-registration-list/employee-registration-list.component';
// import { UpdateEmployeeRegistrationComponent } from './update-employee-registration/update-employee-registration.component'

@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    CreateEmployeeComponent,
    UpdateEmployeeComponent,
    EmployeeDetailsComponent,
    AllocationsComponent,
    EmployeesComponent,
    ProjectsComponent,
    CreateProjectsComponent,
    // AdminRegistrationsComponent,
    // EmployeeRegistrationsComponent,
    // EmployeeRegistrationDetailsComponent,
    // EmployeeRegistrationListComponent,
    // UpdateEmployeeRegistrationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
