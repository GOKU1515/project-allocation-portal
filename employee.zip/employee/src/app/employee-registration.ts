export class EmployeeRegistration{
    id!: number;
    firstName!: string;
    lastName!: string;
    emailId!: string;
    designation! :string;
    userName! :string;
    password! :string;
}