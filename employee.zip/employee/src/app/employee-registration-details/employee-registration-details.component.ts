import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-registration-details',
  templateUrl: './employee-registration-details.component.html',
  styleUrl: './employee-registration-details.component.css'
})
export class EmployeeRegistrationDetailsComponent {

}
