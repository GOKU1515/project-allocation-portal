import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeRegistrationDetailsComponent } from './employee-registration-details.component';

describe('EmployeeRegistrationDetailsComponent', () => {
  let component: EmployeeRegistrationDetailsComponent;
  let fixture: ComponentFixture<EmployeeRegistrationDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeRegistrationDetailsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmployeeRegistrationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
