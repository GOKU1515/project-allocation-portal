// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-admin-registrations',
//   templateUrl: './admin-registrations.component.html',
//   styleUrl: './admin-registrations.component.css'
// })
// export class AdminRegistrationsComponent {

// }
