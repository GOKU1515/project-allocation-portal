// export class Employee {
//     id!: number;
//     firstName!: string;
//     lastName!: string;
//     emailId!: string;
// }


export class Employee {
    id!: number;
    firstName!: string;
    lastName!: string;
    emailId!: string;
    designation! :string;
    userName! : string;
    password! : string;
    status!: string; // status can be 'on-bench' or 'allocated'
  }
  