import { Component, OnInit } from '@angular/core';
import { Project } from '../project';
import { ProjectService } from '../services/project.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-projects',
  templateUrl: './create-projects.component.html',
  styleUrl: './create-projects.component.css'
})
export class CreateProjectsComponent implements OnInit {

  project: Project = new Project();
  constructor(private projectService: ProjectService,
    private router: Router) { }

  ngOnInit(): void {
  }

  saveProject(){
    this.projectService.createProject(this.project).subscribe( data =>{
      console.log(data);
      this.goToProjects();
    },
    error => console.log(error));
  }

  goToProjects(){
    this.router.navigate(['/projects']);
  }
  
  onSubmit(){
    console.log(this.project);
    this.saveProject();
  }
}
