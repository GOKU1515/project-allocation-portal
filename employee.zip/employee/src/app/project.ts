export class Project {
    id!: number;
    projectName!: string;
    description!: string;
    startDate!: Date;
    endDate!: Date;
  }
  