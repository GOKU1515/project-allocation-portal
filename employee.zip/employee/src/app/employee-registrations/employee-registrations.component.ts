// import { Component, OnInit } from '@angular/core';
// import { EmployeeRegistration } from '../employee-registration';
// import { EmployeeRegistrationService } from '../employee-registration.service';
// import { Router } from '@angular/router';

// @Component({
//   selector: 'app-employee-registrations',
//   templateUrl: './employee-registrations.component.html',
//   styleUrl: './employee-registrations.component.css'
// })
// export class EmployeeRegistrationsComponent implements OnInit{
// // employeeRegistration: any;
// employeeRegistrations: EmployeeRegistration = new EmployeeRegistration();
// // employeeRegistration: any;
//   constructor(private employeeReistrationService: EmployeeRegistrationService,
//     private router: Router) { }

//   ngOnInit(): void {
//   }

//   saveEmployee(){
//     this.employeeReistrationService.createEmployee(this.employeeRegistrations).subscribe( data =>{
//       console.log(data);
//       this.goToEmployeeList();
//     },
//     error => console.log(error));
//   }

//   goToEmployeeList(){
//     this.router.navigate(['/employees']);
//   }
  
//   onSubmit(){
//     console.log(this.employeeRegistrations);
//     this.saveEmployee();
//   }


// }
