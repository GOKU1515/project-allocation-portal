import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeRegistrationsComponent } from './employee-registrations.component';

describe('EmployeeRegistrationsComponent', () => {
  let component: EmployeeRegistrationsComponent;
  let fixture: ComponentFixture<EmployeeRegistrationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeRegistrationsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmployeeRegistrationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
