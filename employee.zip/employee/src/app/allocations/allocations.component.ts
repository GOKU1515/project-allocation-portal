// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-allocations',
//   templateUrl: './allocations.component.html',
//   styleUrl: './allocations.component.css'
// })
// export class AllocationsComponent {

// }



import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { ProjectService } from '../services/project.service';
import { Employee } from '../employee';
import { Project } from '../project';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-allocations',
  templateUrl: './allocations.component.html',
  styleUrls: ['./allocations.component.css']
})
export class AllocationsComponent implements OnInit {

  employees: Employee[] = [];
  projects: Project[] = [];
  selectedEmployeeId: number | undefined;
  selectedProjectId: number | undefined;

  constructor(private employeeService: EmployeeService, private projectService: ProjectService) { }

  ngOnInit(): void {
    this.loadEmployeesOnBench();
    this.loadProjects();
  }

  private loadEmployeesOnBench() {
    this.employeeService.getEmployeesOnBench()
      .pipe(
        catchError(error => {
          console.error('Error fetching employees on bench:', error);
          return throwError(error);
        })
      )
      .subscribe(data => {
        this.employees = data;
      });
  }

  private loadProjects() {
    this.projectService.getProjects()
      .pipe(
        catchError(error => {
          console.error('Error fetching projects:', error);
          return throwError(error);
        })
      )
      .subscribe(data => {
        this.projects = data;
      });
  }

  allocateProject() {
    if (this.selectedEmployeeId && this.selectedProjectId) {
      this.projectService.allocateProject(this.selectedEmployeeId, this.selectedProjectId)
        .pipe(
          catchError(error => {
            console.error('Error allocating project:', error);
            return throwError(error);
          })
        )
        .subscribe(response => {
          console.log('Project allocated successfully');
          this.loadEmployeesOnBench(); // Refresh the employee list
        });
    } else {
      console.log('Please select an employee and a project');
    }
  }
}
